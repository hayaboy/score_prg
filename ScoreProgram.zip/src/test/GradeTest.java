package test;

import school.School;
import school.Subject;
import school.report.GenerateGradeReport;

public class GradeTest {
	
	School goodSchool = School.getInstance();
	
	Subject korean;
	Subject math;
	
	GenerateGradeReport gradeReport = new GenerateGradeReport();
	
	
	
	
	

}
